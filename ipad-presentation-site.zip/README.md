# iPad Presentation

Classroom presentation website: https://angusma0711.github.io/ipad-presentation/

Compiled deployment of the local ipad-presentation project. Firebase handles anonymous classroom synchronization.

Both devices need Internet access; they can use different Wi-Fi networks.
